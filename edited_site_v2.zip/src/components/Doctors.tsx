import React from 'react';
import { motion } from 'motion/react';
import { DOCTORS } from '../constants';
import { GraduationCap, Award, Briefcase } from 'lucide-react';

export const Doctors = () => {
  return (
    <section id="doctors" className="section-padding bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <span className="text-medical-teal font-bold uppercase tracking-widest text-sm mb-4 block">
            Meet Our Experts
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-medical-dark mb-6">
            Skilled Hands, <span className="text-medical-teal">Caring Hearts.</span>
          </h2>
          <p className="text-gray-500 max-w-2xl mx-auto">
            Our team of highly qualified specialists is dedicated to providing 
            the highest standard of dental care in a comfortable environment.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {DOCTORS.map((doctor, index) => (
            <motion.div
              key={doctor.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
              className="group relative"
            >
              <div className="glass rounded-[3rem] p-8 flex flex-col lg:flex-row gap-8 items-center lg:items-start hover:shadow-2xl transition-all duration-500">
                <div className="w-48 h-48 lg:w-64 lg:h-64 rounded-[2.5rem] overflow-hidden shrink-0 shadow-xl">
                  <img
                    src={doctor.image}
                    alt={doctor.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                </div>
                
                <div className="flex-1 text-center lg:text-left">
                  <h3 className="text-3xl font-bold text-medical-dark mb-2">{doctor.name}</h3>
                  <p className="text-medical-teal font-bold mb-6">{doctor.specialization}</p>
                  
                  <div className="grid grid-cols-1 gap-4 mb-8">
                    <div className="flex items-center gap-3 justify-center lg:justify-start">
                      <GraduationCap className="text-medical-teal" size={20} />
                      <span className="text-sm text-gray-600 font-medium">{doctor.qualification}</span>
                    </div>
                    <div className="flex items-center gap-3 justify-center lg:justify-start">
                      <Briefcase className="text-medical-teal" size={20} />
                      <span className="text-sm text-gray-600 font-medium">{doctor.experience} Experience</span>
                    </div>
                  </div>
                  
                  <p className="text-gray-500 leading-relaxed italic">
                    "{doctor.bio}"
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
