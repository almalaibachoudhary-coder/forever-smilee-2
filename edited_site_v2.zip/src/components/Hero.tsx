import React from 'react';
import { motion } from 'motion/react';
import { Phone, MessageCircle, Calendar, Star, Shield, Award } from 'lucide-react';
import { CLINIC_DATA } from '../constants';

export const Hero = () => {
  return (
    <section className="relative h-screen min-h-[700px] w-full overflow-hidden flex items-center justify-center">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=2000"
          alt="Modern Dental Clinic"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-medical-dark/80 via-medical-dark/40 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-white"
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 glass rounded-full mb-6"
          >
            <Star className="text-yellow-400 fill-yellow-400" size={16} />
            <span className="text-sm font-bold">5.0 Rated Clinic in Ranchi</span>
          </motion.div>

          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
            Your Smile, <br />
            <span className="text-medical-accent">Our Priority.</span>
          </h1>
          
          <p className="text-lg md:text-xl text-medical-blue/80 mb-10 max-w-xl leading-relaxed">
            Experience advanced, painless dental care with Forever Smile. 
            We combine futuristic technology with expert care to give you the smile you deserve.
          </p>

          <div className="flex flex-wrap gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn-primary flex items-center gap-2"
            >
              <Calendar size={20} /> Book Appointment
            </motion.button>
            
            <div className="flex gap-4">
              <motion.a
                href={`tel:${CLINIC_DATA.phone}`}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="w-14 h-14 glass flex items-center justify-center rounded-full text-white hover:bg-medical-teal transition-colors"
              >
                <Phone size={24} />
              </motion.a>
              <motion.a
                href={`https://wa.me/${CLINIC_DATA.whatsapp}`}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="w-14 h-14 glass flex items-center justify-center rounded-full text-white hover:bg-green-500 transition-colors"
              >
                <MessageCircle size={24} />
              </motion.a>
            </div>
          </div>

          <div className="mt-12 flex items-center gap-8 opacity-70">
            <div className="flex items-center gap-2">
              <Shield size={20} />
              <span className="text-sm font-medium">Certified Dentists</span>
            </div>
            <div className="flex items-center gap-2">
              <Award size={20} />
              <span className="text-sm font-medium">Modern Equipment</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="hidden lg:block relative"
        >
          <div className="glass-dark p-8 rounded-[3rem] relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-medical-teal/20 blur-3xl rounded-full" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-medical-accent/20 blur-3xl rounded-full" />
            
            <img
              src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&q=80&w=600"
              alt="Patient Smiling"
              className="rounded-[2rem] shadow-2xl relative z-10"
              referrerPolicy="no-referrer"
            />
            
            <div className="absolute -bottom-6 -right-6 glass p-6 rounded-3xl shadow-2xl z-20 flex items-center gap-4">
              <div className="w-12 h-12 bg-medical-teal rounded-full flex items-center justify-center text-white">
                <Star fill="white" size={20} />
              </div>
              <div>
                <div className="text-medical-dark font-bold">172+ Reviews</div>
                <div className="text-medical-teal text-sm font-medium">Verified Patients</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
