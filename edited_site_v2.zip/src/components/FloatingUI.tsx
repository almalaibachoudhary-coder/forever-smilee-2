import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, MessageCircle, X, Gift, ArrowRight } from 'lucide-react';
import { CLINIC_DATA } from '../constants';

export const FloatingUI = () => {
  const [showExitPopup, setShowExitPopup] = useState(false);

  useEffect(() => {
    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !localStorage.getItem('exit_popup_shown')) {
        setShowExitPopup(true);
        localStorage.setItem('exit_popup_shown', 'true');
      }
    };
    document.addEventListener('mouseleave', handleMouseLeave);
    return () => document.removeEventListener('mouseleave', handleMouseLeave);
  }, []);

  return (
    <>
      {/* Floating Buttons */}
      <div className="fixed bottom-8 right-8 z-[60] flex flex-col gap-4">
        <motion.a
          href={`https://wa.me/${CLINIC_DATA.whatsapp}`}
          target="_blank"
          whileHover={{ scale: 1.1, x: -5 }}
          whileTap={{ scale: 0.9 }}
          className="w-16 h-16 bg-green-500 text-white rounded-full shadow-2xl flex items-center justify-center hover:bg-green-600 transition-colors group relative"
        >
          <MessageCircle size={32} />
          <span className="absolute right-20 bg-white text-green-600 px-4 py-2 rounded-xl text-sm font-bold shadow-xl opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
            Chat with us
          </span>
        </motion.a>
        
        <motion.a
          href={`tel:${CLINIC_DATA.phone}`}
          whileHover={{ scale: 1.1, x: -5 }}
          whileTap={{ scale: 0.9 }}
          className="w-16 h-16 bg-medical-teal text-white rounded-full shadow-2xl flex items-center justify-center hover:bg-medical-accent transition-colors group relative"
        >
          <Phone size={28} />
          <span className="absolute right-20 bg-white text-medical-teal px-4 py-2 rounded-xl text-sm font-bold shadow-xl opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
            Call now
          </span>
        </motion.a>
      </div>

      {/* Exit Intent Popup */}
      <AnimatePresence>
        {showExitPopup && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowExitPopup(false)}
              className="absolute inset-0 bg-medical-dark/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-lg glass rounded-[3rem] p-10 shadow-2xl overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-medical-teal/10 blur-3xl rounded-full" />
              
              <button 
                onClick={() => setShowExitPopup(false)}
                className="absolute top-6 right-6 p-2 text-gray-400 hover:text-medical-dark transition-colors"
              >
                <X size={24} />
              </button>

              <div className="w-20 h-20 bg-medical-blue rounded-3xl flex items-center justify-center text-medical-teal mb-8">
                <Gift size={40} />
              </div>

              <h2 className="text-3xl font-bold text-medical-dark mb-4">Wait! Don't Leave Yet.</h2>
              <p className="text-gray-500 text-lg mb-8 leading-relaxed">
                Get a <span className="text-medical-teal font-bold">FREE Consultation</span> and 
                <span className="text-medical-teal font-bold"> 20% OFF</span> on your first cleaning. 
                Limited time offer for new patients!
              </p>

              <div className="flex flex-col gap-4">
                <button 
                  onClick={() => setShowExitPopup(false)}
                  className="btn-primary w-full py-5 text-lg flex items-center justify-center gap-3"
                >
                  Claim My Offer <ArrowRight size={20} />
                </button>
                <button 
                  onClick={() => setShowExitPopup(false)}
                  className="text-gray-400 font-bold hover:text-gray-600 transition-colors text-sm"
                >
                  No thanks, I'll pay full price
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
