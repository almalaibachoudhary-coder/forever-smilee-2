import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Phone, MessageCircle, Calendar } from 'lucide-react';
import { CLINIC_DATA } from '../constants';
import { cn } from '../lib/utils';

export const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'Services', href: '#services' },
    { name: 'Doctors', href: '#doctors' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-500 px-6 py-4',
        isScrolled ? 'py-3' : 'py-6'
      )}
    >
      <div
        className={cn(
          'max-w-7xl mx-auto rounded-full transition-all duration-500 flex items-center justify-between px-6 py-3',
          isScrolled ? 'glass shadow-2xl' : 'bg-transparent'
        )}
      >
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-medical-teal rounded-xl flex items-center justify-center shadow-lg shadow-medical-teal/30">
            <span className="text-white font-bold text-xl">F</span>
          </div>
          <div className="flex flex-col">
            <span className={cn("font-bold text-lg leading-none", isScrolled ? "text-medical-dark" : "text-white")}>
              Forever Smile
            </span>
            <span className={cn("text-[10px] font-medium tracking-widest uppercase opacity-70", isScrolled ? "text-medical-teal" : "text-medical-blue")}>
              Dental Clinic
            </span>
          </div>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className={cn(
                'text-sm font-semibold transition-colors hover:text-medical-teal',
                isScrolled ? 'text-medical-dark' : 'text-white'
              )}
            >
              {link.name}
            </a>
          ))}
          <button className="btn-primary py-2 px-6 text-sm">
            Book Now
          </button>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden p-2 text-medical-teal"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu className={isScrolled ? "text-medical-dark" : "text-white"} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-24 left-6 right-6 glass rounded-3xl p-8 md:hidden shadow-2xl"
          >
            <div className="flex flex-col gap-6">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-lg font-semibold text-medical-dark hover:text-medical-teal"
                >
                  {link.name}
                </a>
              ))}
              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-100">
                <a
                  href={`tel:${CLINIC_DATA.phone}`}
                  className="flex items-center justify-center gap-2 p-3 bg-medical-blue text-medical-teal rounded-2xl font-bold"
                >
                  <Phone size={18} /> Call
                </a>
                <a
                  href={`https://wa.me/${CLINIC_DATA.whatsapp}`}
                  className="flex items-center justify-center gap-2 p-3 bg-green-50 text-green-600 rounded-2xl font-bold"
                >
                  <MessageCircle size={18} /> WhatsApp
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
