import React from 'react';
import { motion } from 'motion/react';
import { TESTIMONIALS, CLINIC_DATA } from '../constants';
import { Star, Quote } from 'lucide-react';

export const Testimonials = () => {
  return (
    <section className="section-padding bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-12 mb-20">
          <div className="max-w-xl text-center md:text-left">
            <span className="text-medical-teal font-bold uppercase tracking-widest text-sm mb-4 block">
              Patient Stories
            </span>
            <h2 className="text-4xl md:text-5xl font-bold text-medical-dark mb-6">
              Loved by <span className="text-medical-teal">170+ Patients.</span>
            </h2>
          </div>
          
          <div className="glass p-8 rounded-3xl flex items-center gap-6 shadow-2xl">
            <div className="text-center">
              <div className="text-4xl font-black text-medical-dark">5.0</div>
              <div className="flex gap-1 justify-center my-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={14} className="text-yellow-400 fill-yellow-400" />
                ))}
              </div>
              <div className="text-xs font-bold text-gray-400 uppercase tracking-tighter">Google Rating</div>
            </div>
            <div className="w-px h-16 bg-gray-100" />
            <div className="text-center">
              <div className="text-4xl font-black text-medical-dark">172</div>
              <div className="text-xs font-bold text-gray-400 uppercase tracking-tighter mt-2">Total Reviews</div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="relative"
            >
              <div className="h-full p-10 rounded-[3rem] bg-medical-blue/10 border border-medical-blue/20 hover:bg-white hover:shadow-2xl transition-all duration-500 group">
                <Quote className="text-medical-teal/20 absolute top-8 right-8" size={64} />
                
                <div className="flex gap-1 mb-6">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} size={16} className="text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                
                <p className="text-gray-600 text-lg leading-relaxed mb-8 relative z-10">
                  "{testimonial.content}"
                </p>
                
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-medical-teal rounded-full flex items-center justify-center text-white font-bold text-xl">
                    {testimonial.name[0]}
                  </div>
                  <div>
                    <div className="font-bold text-medical-dark">{testimonial.name}</div>
                    <div className="text-xs text-gray-400 font-medium uppercase tracking-widest">{testimonial.role} • {testimonial.date}</div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
