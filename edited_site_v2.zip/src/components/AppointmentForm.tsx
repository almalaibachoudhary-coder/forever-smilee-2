import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Send, Calendar, User, Phone, MessageSquare, CheckCircle2 } from 'lucide-react';
import { CLINIC_DATA, SERVICES } from '../constants';

export const AppointmentForm = () => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    service: '',
    date: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate WhatsApp integration
    const text = `New Appointment Request:\nName: ${formData.name}\nPhone: ${formData.phone}\nService: ${formData.service}\nDate: ${formData.date}\nMessage: ${formData.message}`;
    const whatsappUrl = `https://wa.me/${CLINIC_DATA.whatsapp}?text=${encodeURIComponent(text)}`;
    
    setIsSubmitted(true);
    setTimeout(() => {
      window.open(whatsappUrl, '_blank');
      setIsSubmitted(false);
    }, 2000);
  };

  return (
    <section id="contact" className="section-padding bg-medical-dark relative overflow-hidden">
      {/* Decorative Background */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-medical-teal blur-[120px] rounded-full" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-medical-accent blur-[120px] rounded-full" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div>
            <span className="text-medical-accent font-bold uppercase tracking-widest text-sm mb-4 block">
              Book Your Visit
            </span>
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-8">
              Ready for a <br />
              <span className="text-medical-accent">Perfect Smile?</span>
            </h2>
            <p className="text-medical-blue/60 text-lg mb-12 leading-relaxed">
              Fill out the form to schedule your consultation. Our team will 
              get back to you within 2 hours to confirm your slot.
            </p>

            <div className="space-y-8">
              <div className="flex items-center gap-6">
                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-medical-accent">
                  <Phone size={24} />
                </div>
                <div>
                  <div className="text-white/40 text-sm uppercase tracking-wider font-bold">Call Us Directly</div>
                  <div className="text-white text-xl font-bold">{CLINIC_DATA.phone}</div>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-green-400">
                  <MessageSquare size={24} />
                </div>
                <div>
                  <div className="text-white/40 text-sm uppercase tracking-wider font-bold">WhatsApp Us</div>
                  <div className="text-white text-xl font-bold">Available 24/7</div>
                </div>
              </div>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            className="glass-dark p-10 rounded-[3rem] border-white/10"
          >
            {isSubmitted ? (
              <div className="text-center py-20">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="w-20 h-20 bg-medical-accent rounded-full flex items-center justify-center mx-auto mb-6"
                >
                  <CheckCircle2 size={40} className="text-medical-dark" />
                </motion.div>
                <h3 className="text-2xl font-bold text-white mb-4">Request Sent!</h3>
                <p className="text-medical-blue/60">Redirecting you to WhatsApp for confirmation...</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-white/60 ml-2">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" size={18} />
                      <input
                        required
                        type="text"
                        placeholder="John Doe"
                        className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-medical-accent transition-colors"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-white/60 ml-2">Phone Number</label>
                    <div className="relative">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" size={18} />
                      <input
                        required
                        type="tel"
                        placeholder="+91 00000 00000"
                        className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-medical-accent transition-colors"
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-white/60 ml-2">Service Needed</label>
                    <select
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-medical-accent transition-colors appearance-none"
                      value={formData.service}
                      onChange={(e) => setFormData({...formData, service: e.target.value})}
                    >
                      <option value="" className="bg-medical-dark">Select Service</option>
                      {SERVICES.map(s => (
                        <option key={s.id} value={s.title} className="bg-medical-dark">{s.title}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-white/60 ml-2">Preferred Date</label>
                    <div className="relative">
                      <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" size={18} />
                      <input
                        required
                        type="date"
                        className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-medical-accent transition-colors"
                        value={formData.date}
                        onChange={(e) => setFormData({...formData, date: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-white/60 ml-2">Message (Optional)</label>
                  <textarea
                    rows={4}
                    placeholder="Tell us about your dental concern..."
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-medical-accent transition-colors resize-none"
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                  />
                </div>

                <button type="submit" className="w-full btn-primary py-5 text-lg flex items-center justify-center gap-3">
                  <Send size={20} /> Confirm Appointment
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};
