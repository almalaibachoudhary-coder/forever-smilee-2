import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { AlertCircle, Zap, CheckCircle, ArrowRight } from 'lucide-react';

export const ScrollStory = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  const sections = [
    {
      title: "The Problem",
      subtitle: "Tooth pain shouldn't stop your life.",
      description: "Ignoring dental discomfort can lead to severe infections, bone loss, and systemic health issues. Don't let a small ache become a big problem.",
      icon: <AlertCircle className="text-red-500" size={48} />,
      color: "from-red-50 to-white",
      accent: "bg-red-500"
    },
    {
      title: "The Cause",
      subtitle: "Hidden damage beneath the surface.",
      description: "Cavities, gum disease, and structural damage often hide where you can't see. Our advanced diagnostics reveal the root cause instantly.",
      icon: <Zap className="text-orange-500" size={48} />,
      color: "from-orange-50 to-white",
      accent: "bg-orange-500"
    },
    {
      title: "The Solution",
      subtitle: "Advanced, Painless Technology.",
      description: "From laser dentistry to painless root canals, we use futuristic tools to restore your smile with zero discomfort and maximum precision.",
      icon: <CheckCircle className="text-medical-teal" size={48} />,
      color: "from-medical-blue to-white",
      accent: "bg-medical-teal"
    }
  ];

  return (
    <div ref={containerRef} className="relative">
      {sections.map((section, index) => {
        return (
          <section
            key={index}
            className={`min-h-screen flex items-center justify-center sticky top-0 bg-gradient-to-b ${section.color}`}
          >
            <div className="max-w-4xl mx-auto px-6 text-center">
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="mb-8 flex justify-center"
              >
                <div className={`w-24 h-24 rounded-3xl ${section.accent}/10 flex items-center justify-center shadow-inner`}>
                  {section.icon}
                </div>
              </motion.div>

              <motion.span
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                className={`text-sm font-bold uppercase tracking-widest mb-4 block ${section.accent.replace('bg-', 'text-')}`}
              >
                Step 0{index + 1}
              </motion.span>

              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-4xl md:text-6xl font-bold text-medical-dark mb-6"
              >
                {section.title}
              </motion.h2>

              <motion.h3
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-xl md:text-2xl font-medium text-gray-600 mb-8"
              >
                {section.subtitle}
              </motion.h3>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="text-lg text-gray-500 max-w-2xl mx-auto leading-relaxed mb-12"
              >
                {section.description}
              </motion.p>

              {index === 2 && (
                <motion.button
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  whileHover={{ scale: 1.05 }}
                  className="btn-primary flex items-center gap-2 mx-auto"
                >
                  Start Your Journey <ArrowRight size={20} />
                </motion.button>
              )}
            </div>
          </section>
        );
      })}
    </div>
  );
};
