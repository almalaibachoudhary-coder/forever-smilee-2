import React from 'react';
import { CLINIC_DATA } from '../constants';
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Twitter } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-medical-dark text-white pt-20 pb-10 px-6 md:px-12 lg:px-24">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          <div className="space-y-8">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-medical-teal rounded-xl flex items-center justify-center shadow-lg shadow-medical-teal/30">
                <span className="text-white font-bold text-xl">F</span>
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-lg leading-none text-white">Forever Smile</span>
                <span className="text-[10px] font-medium tracking-widest uppercase text-medical-accent">Dental Clinic</span>
              </div>
            </div>
            <p className="text-white/50 leading-relaxed">
              Providing premium dental care in Ranchi. We are committed to 
              excellence, patient comfort, and futuristic dental solutions.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-medical-teal transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-medical-teal transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-medical-teal transition-colors">
                <Twitter size={18} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8 text-medical-accent">Quick Links</h4>
            <ul className="space-y-4 text-white/60">
              <li><a href="#" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Our Services</a></li>
              <li><a href="#doctors" className="hover:text-white transition-colors">Meet Doctors</a></li>
              <li><a href="#gallery" className="hover:text-white transition-colors">Clinic Gallery</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Book Appointment</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8 text-medical-accent">Opening Hours</h4>
            <ul className="space-y-4 text-white/60">
              <li className="flex justify-between"><span>Mon - Sat</span> <span>10:00 AM - 8:00 PM</span></li>
              <li className="flex justify-between text-red-400"><span>Sunday</span> <span>Closed</span></li>
            </ul>
            <div className="mt-8 p-4 bg-white/5 rounded-2xl border border-white/10">
              <div className="flex items-center gap-3 text-sm">
                <Clock className="text-medical-accent" size={16} />
                <span>Emergency calls available 24/7</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8 text-medical-accent">Contact Info</h4>
            <ul className="space-y-6 text-white/60">
              <li className="flex gap-4">
                <MapPin className="text-medical-accent shrink-0" size={20} />
                <span className="text-sm leading-relaxed">{CLINIC_DATA.address}</span>
              </li>
              <li className="flex gap-4">
                <Phone className="text-medical-accent shrink-0" size={20} />
                <span className="text-sm">{CLINIC_DATA.phone}</span>
              </li>
              <li className="flex gap-4">
                <Mail className="text-medical-accent shrink-0" size={20} />
                <span className="text-sm">{CLINIC_DATA.email}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="h-px bg-white/10 w-full mb-10" />
        
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 text-white/40 text-sm">
          <p>© 2026 Forever Smile Dental Clinic. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
