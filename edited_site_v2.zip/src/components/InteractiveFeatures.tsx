import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { ArrowLeftRight, Info, Sparkles } from 'lucide-react';

export const InteractiveFeatures = () => {
  const [sliderPos, setSliderPos] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const position = ((x - rect.left) / rect.width) * 100;
    setSliderPos(Math.min(Math.max(position, 0), 100));
  };

  return (
    <section className="section-padding bg-medical-blue/20">
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-20 items-center">
        <div>
          <span className="text-medical-teal font-bold uppercase tracking-widest text-sm mb-4 block">
            Visual Results
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-medical-dark mb-8">
            See the <span className="text-medical-teal">Transformation.</span>
          </h2>
          <p className="text-gray-500 text-lg mb-10 leading-relaxed">
            Our advanced smile design and whitening treatments deliver 
            life-changing results. Drag the slider to see the before and 
            after of a typical whitening procedure.
          </p>
          
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-medical-teal shadow-lg shrink-0">
                <Sparkles size={24} />
              </div>
              <div>
                <h4 className="font-bold text-medical-dark">Laser Whitening</h4>
                <p className="text-sm text-gray-500">Up to 8 shades whiter in just one 45-minute session.</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-medical-teal shadow-lg shrink-0">
                <Info size={24} />
              </div>
              <div>
                <h4 className="font-bold text-medical-dark">Painless Process</h4>
                <p className="text-sm text-gray-500">Zero sensitivity treatments with long-lasting results.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="relative">
          <div className="relative group">
            <div 
              ref={containerRef}
              className="relative aspect-[4/3] rounded-[3rem] overflow-hidden shadow-2xl cursor-ew-resize select-none"
              onMouseMove={handleMove}
              onTouchMove={handleMove}
            >
              {/* After Image */}
              <img 
                src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&q=80&w=800" 
                alt="After Treatment"
                className="absolute inset-0 w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              
              {/* Before Image (Clipped) */}
              <div 
                className="absolute inset-0 w-full h-full overflow-hidden grayscale-[0.5] brightness-[0.8]"
                style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
              >
                <img 
                  src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&q=80&w=800" 
                  alt="Before Treatment"
                  className="absolute inset-0 w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Slider Handle */}
              <div 
                className="absolute top-0 bottom-0 w-1 bg-white shadow-2xl flex items-center justify-center"
                style={{ left: `${sliderPos}%` }}
              >
                <div className="w-12 h-12 bg-white rounded-full shadow-2xl flex items-center justify-center text-medical-teal border-4 border-medical-blue">
                  <ArrowLeftRight size={20} />
                </div>
              </div>

              {/* Labels */}
              <div className="absolute bottom-6 left-6 glass px-4 py-2 rounded-full text-xs font-bold text-medical-dark">BEFORE</div>
              <div className="absolute bottom-6 right-6 glass px-4 py-2 rounded-full text-xs font-bold text-medical-dark">AFTER</div>
            </div>

            {/* Interactive 3D Tooth Simulation Overlay */}
            <motion.div 
              drag
              dragConstraints={{ left: -20, right: 20, top: -20, bottom: 20 }}
              whileHover={{ scale: 1.1 }}
              className="absolute -top-12 -left-12 w-32 h-32 glass rounded-3xl flex items-center justify-center shadow-2xl cursor-grab active:cursor-grabbing z-20"
            >
              <motion.svg 
                animate={{ rotateY: [0, 360] }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                viewBox="0 0 24 24" 
                className="w-16 h-16 text-medical-teal"
                fill="none" 
                stroke="currentColor" 
                strokeWidth="1.5"
              >
                <path d="M7 3C4.23858 3 2 5.23858 2 8C2 10.7614 4.23858 13 7 13C9.76142 13 12 10.7614 12 8C12 5.23858 9.76142 3 7 3Z" />
                <path d="M17 3C14.2386 3 12 5.23858 12 8C12 10.7614 14.2386 13 17 13C19.7614 13 22 10.7614 22 8C22 5.23858 19.7614 3 17 3Z" />
                <path d="M7 13C7 13 7 21 12 21C17 21 17 13 17 13" />
                <path d="M12 8V13" />
              </motion.svg>
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-medical-teal text-white text-[8px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap">3D INTERACTIVE</div>
            </motion.div>
          </div>
          
          {/* Decorative Elements */}
          <div className="absolute -top-6 -right-6 w-24 h-24 bg-medical-accent/20 blur-3xl rounded-full" />
          <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-medical-teal/20 blur-3xl rounded-full" />
        </div>
      </div>
    </section>
  );
};
