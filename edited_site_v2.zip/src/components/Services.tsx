import React from 'react';
import { motion } from 'motion/react';
import { SERVICES } from '../constants';
import * as Icons from 'lucide-react';
import { ArrowRight } from 'lucide-react';

export const Services = () => {
  return (
    <section id="services" className="section-padding bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto mb-16">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div>
            <span className="text-medical-teal font-bold uppercase tracking-widest text-sm mb-4 block">
              Our Expertise
            </span>
            <h2 className="text-4xl md:text-5xl font-bold text-medical-dark">
              Futuristic Dental <br /> Solutions.
            </h2>
          </div>
          <p className="text-gray-500 max-w-md">
            We offer a comprehensive range of dental services using the latest 
            technology to ensure the best outcomes for our patients.
          </p>
        </div>
      </div>

      <div className="flex overflow-x-auto gap-8 pb-12 no-scrollbar snap-x snap-mandatory px-4 -mx-4">
        {SERVICES.map((service, index) => {
          const IconComponent = (Icons as any)[service.icon];
          return (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="min-w-[300px] md:min-w-[400px] snap-center"
            >
              <div className="group h-full p-8 rounded-[2.5rem] bg-medical-blue/30 border border-medical-blue hover:bg-white hover:shadow-2xl hover:shadow-medical-teal/10 transition-all duration-500">
                <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mb-8 shadow-lg group-hover:bg-medical-teal group-hover:text-white transition-colors duration-500">
                  <IconComponent size={32} />
                </div>
                
                <h3 className="text-2xl font-bold text-medical-dark mb-4">
                  {service.title}
                </h3>
                
                <p className="text-gray-500 mb-8 leading-relaxed">
                  {service.description}
                </p>
                
                <button className="flex items-center gap-2 text-medical-teal font-bold hover:gap-4 transition-all">
                  Learn More <ArrowRight size={18} />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
};
