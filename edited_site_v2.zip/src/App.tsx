/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { Component, Suspense } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ScrollStory } from './components/ScrollStory';
import { Services } from './components/Services';
import { InteractiveFeatures } from './components/InteractiveFeatures';
import { Doctors } from './components/Doctors';
import { Testimonials } from './components/Testimonials';
import { Gallery } from './components/Gallery';
import { AppointmentForm } from './components/AppointmentForm';
import { Footer } from './components/Footer';
import { FloatingUI } from './components/FloatingUI';

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("App Error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-medical-blue/20 p-6 text-center">
          <div className="glass p-12 rounded-[3rem] max-w-lg">
            <h2 className="text-3xl font-bold text-medical-dark mb-4">Something went wrong.</h2>
            <p className="text-gray-500 mb-8">We're sorry for the inconvenience. Please try refreshing the page.</p>
            <button 
              onClick={() => window.location.reload()}
              className="btn-primary"
            >
              Refresh Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <div className="relative">
        <Navbar />
        <main>
          <Hero />
          <ScrollStory />
          <Services />
          <InteractiveFeatures />
          <Doctors />
          <Gallery />
          <Testimonials />
          <AppointmentForm />
        </main>
        <Footer />
        <FloatingUI />
      </div>
    </ErrorBoundary>
  );
}
