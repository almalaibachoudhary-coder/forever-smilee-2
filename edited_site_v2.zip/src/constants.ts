export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  rating: number;
  date: string;
}

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  qualification: string;
  experience: string;
  image: string;
  bio: string;
}

export const CLINIC_DATA = {
  name: "Forever Smile Dental Clinic",
  hindiName: "फॉरेवर स्माइल डेंटल क्लिनिक",
  rating: 5.0,
  reviewsCount: 172,
  address: "Mission Complex, Beside St. John's School Mission Chowk, Purulia Rd, Ranchi, Jharkhand 834001",
  phone: "084099 81910",
  whatsapp: "918409981910",
  email: "info@foreversmile.com",
  openingHours: {
    mon: "10:00 AM - 8:00 PM",
    tue: "10:00 AM - 8:00 PM",
    wed: "10:00 AM - 8:00 PM",
    thu: "10:00 AM - 8:00 PM",
    fri: "10:00 AM - 8:00 PM",
    sat: "10:00 AM - 8:00 PM",
    sun: "Closed"
  }
};

export const SERVICES: Service[] = [
  {
    id: "rct",
    title: "Root Canal Treatment",
    description: "Painless RCT using advanced rotary instruments for saving your natural teeth.",
    icon: "Activity"
  },
  {
    id: "implants",
    title: "Dental Implants",
    description: "Permanent and natural-looking tooth replacement solutions with lifetime warranty.",
    icon: "ShieldCheck"
  },
  {
    id: "braces",
    title: "Orthodontics (Braces)",
    description: "Metal, ceramic, and invisible aligners for a perfectly aligned smile.",
    icon: "Layers"
  },
  {
    id: "whitening",
    title: "Teeth Whitening",
    description: "Professional laser whitening for a brighter, more confident smile in one visit.",
    icon: "Sparkles"
  },
  {
    id: "smile-design",
    title: "Smile Design",
    description: "Cosmetic reconstruction and veneers for your dream Hollywood smile.",
    icon: "Heart"
  },
  {
    id: "cleaning",
    title: "Scaling & Polishing",
    description: "Deep cleaning and stain removal to maintain optimal oral hygiene.",
    icon: "Droplets"
  }
];

export const DOCTORS: Doctor[] = [
  {
    id: "dr-reena",
    name: "Dr. Reena",
    specialization: "Cosmetic & General Dentist",
    qualification: "BDS",
    experience: "10+ Years",
    image: "https://images.unsplash.com/photo-1559839734-2b71f1e3c770?auto=format&fit=crop&q=80&w=400",
    bio: "Expert in painless treatments and cosmetic smile design. Known for her gentle approach and precision."
  },
  {
    id: "dr-noman",
    name: "Dr. Noman",
    specialization: "Oral Surgeon & Implantologist",
    qualification: "BDS, MDS",
    experience: "12+ Years",
    image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=400",
    bio: "Specialist in complex oral surgeries and advanced dental implants. Dedicated to surgical excellence."
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "1",
    name: "Nadeem Ahmad",
    role: "Local Guide",
    content: "One of the best experiences I’ve ever had at a dental clinic. Both Dr. Reena and Dr. Noman are extremely professional, polite, and knowledgeable.",
    rating: 5,
    date: "5 months ago"
  },
  {
    id: "2",
    name: "Kishan Chand Lal",
    role: "Patient",
    content: "Treatment done by Dr Reena was so smooth and painless. Clinic is neat and clean. They use best instruments for good dental treatment.",
    rating: 5,
    date: "5 months ago"
  },
  {
    id: "3",
    name: "Dablu Sajjad",
    role: "Patient",
    content: "One of the best dental clinic in Town. I have undergone a root canal with reconstruction. Both the doctors are highly expert.",
    rating: 5,
    date: "2 months ago"
  }
];
